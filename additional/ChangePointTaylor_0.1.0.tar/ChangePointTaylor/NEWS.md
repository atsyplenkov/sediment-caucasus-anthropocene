# ChangePointTaylor 0.1

* Initial Release
